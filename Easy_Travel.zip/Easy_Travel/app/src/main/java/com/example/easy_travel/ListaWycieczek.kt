package com.example.easy_travel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class ListaWycieczek : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_lista_wycieczek)
    }
}